#ifndef BankCustomer_h
#define BankCustomer_h
class Account
{
    public:
    int Account_Number,branch number ;
    string status,date_opened,subaccounts;
    Account()
    {
        Account_Number=rand(99999,999999);
        status="open";
        
        
    }
    void validator()
    {
        if(status="open")
        {
            void set_status_frozen(int s)
            {
                s=frozen;
            }
            void set_status_closed(int s)
            {
                s=closed;
            }
        }
    }
}
 #endif