#ifndef BankCustomer_h
#define BankCustomer_h

class Customer
{
    public:
    int Account,Work_Phone, Home_Phone,Cell_Phone;
    String Full_Name,Address_Line_1, Address_Line_2, City, Province, Postal_Code;
    int *ptr=NULL;
    Customer(string name)
    {
        Full_Name=name;
        Account= *ptr;
        Address_Line_1="";
        Address_Line_2="";
        City="";
        Province="";
        Postal_Code="";
    }
    void setWork_Phone(int w)
    {
        Work_Phone=w;
    }
    void setHome_Phone(int w)
    {
        Home_Phone=w;
    }
    void setCell_Phone(int w)
    {
        Cell_Phone=w;
    }
    void setAddress_Line_1(int w)
    {
        Address_Line_1=w;
    }
    void setAddress_Line_2(int w)
    {
        Address_Line_2=w;
    }
    void setCity(int w)
    {
        City=w;
    }
    void setProvince(int w)
    {
        Province=w;
    }
    void setPostal_Code(int w)
    {
        Postal_Code=w;
    }
    void getWork_Phone()
    {
        return Work_Phone;
    }
    void getHome_Phone()
    {
        return Home_Phone;
    } 
    void getCell_Phone()
    {
        return Cell_Phone;
    }
    void getAddress_Line_1()
    {
        return Address_Line_1;
    }
    void getAddress_Line_2()
    {
        return Address_Line_2;
    }
    void getCity()
    {
        return City;
    }
    void getProvince()
    {
        return Province;
    }
    void getPostal_Code()
    {
        return Postal_Code;
    }
    void Validator
    {
        if(Full_Name<6)
            {
                cout << "Error in name should be more than 6 characters";
            }
            if(Work_Phone != NULL || Cell_Phone!= NULL || Home_Phone != NULL)
            {
                cout << "Atleast one phone numbers should be decalared";
            }
            if(Address_Line_1 !=NULL && City!=NULL && Province !=NULL && Postal_Code!=NULL)
            {
                 cout << "Address_Line_1 cannot be empty";
            }
    }
};
    