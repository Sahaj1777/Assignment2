
#include <iostream>
#include "BankCustomer.h"
#include "CustomerAccount.h"
using namespace std;

int main()
{
    BankCustomer B1("sahej");
    Account C1;
    
    return 0;
}
